nc64 -w 2 -d 192.168.31.252 15 < zplTesgte.zpl
